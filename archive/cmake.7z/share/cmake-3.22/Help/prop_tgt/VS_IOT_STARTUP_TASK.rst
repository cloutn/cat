VS_IOT_STARTUP_TASK
-------------------

.. versionadded:: 3.4

Visual Studio Windows 10 IoT Continuous Background Task

Specifies that the target should be compiled as a Continuous Background Task library.
