ARCHIVE_OUTPUT_NAME
-------------------

.. |XXX| replace:: :ref:`ARCHIVE <Archive Output Artifacts>`
.. |xxx| replace:: archive
.. include:: XXX_OUTPUT_NAME.txt

See also the :prop_tgt:`ARCHIVE_OUTPUT_NAME_<CONFIG>` target property.
