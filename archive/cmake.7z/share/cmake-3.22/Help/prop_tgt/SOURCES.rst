SOURCES
-------

Source names specified for a target.

List of sources specified for a target.
